
public class oop102car {

    private String carPlate;
    private String carOwner;
    private String carType;
    //private String carColor;
    //private int carDoorQty;     
    private float carEngineCC;    
    //private String carPaxQty;    
    private float carSpeed; 

    public String getCarPlate() {
        return carPlate;
    }

    public void setCarPlate(String carPlate) {
        this.carPlate = carPlate;
    }

    public String getCarOwner() {
        return carOwner;
    }

    public void setCarOwner(String carOwner) {
        this.carOwner = carOwner;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public float getCarEngineCC() {
        return carEngineCC;
    }

    public void setCarEngineCC(float carEngineCC) {
        this.carEngineCC = carEngineCC;
    }

    public float getCarSpeed() {
        return carSpeed;
    }

    public void setCarSpeed(float carSpeed) {
        if (carSpeed < 0 || carSpeed > 30) {
            System.out.println("\n" + "This car has speed limit control. " + "\n"
                    + "\t" + "You have exceeded that limit at " + carSpeed + "mph.\n"
                    + "\t\t" + "Soon ... the car will CRASH!!!" + "\n\n");
            throw new IllegalArgumentException();
        }
        this.carSpeed = carSpeed;
    }
    //
    // Constructor - which helps build an Object
    public oop102car() {
    }
    //
    public oop102car(String co) {
        setCarOwner(co);//carOwner = co;
    }
    //
    public oop102car(String cp, String ct, float cecc, float cs) {
        setCarPlate(cp);//carPlate = cp;
        setCarType(ct);//carType = ct;
        setCarEngineCC(cecc);//carEngineCC = cecc;
        setCarSpeed(cs);//carSpeed = cs;
    }  
    //
    // Using getter and setter
    void accelerate(float speed){   
        float s = getCarSpeed();
        s += speed;
        setCarSpeed(s);    
    }
    //
    /*
    //Before getter and setter were introduced
    float accelerate(float speed){          
        return carSpeed += speed;     
    }
    */
    //
        @Override
    public String toString() {
        return "A " + getCarType() 
         + " bearing car Plate " + getCarPlate()   
         + " with engine capacity of " + getCarEngineCC() + "cc"
         + " was tracked travelling at speed " + getCarSpeed() + " km/h."; 
    }
    //
    /*
    public static void moveCar(Object n1car, boolean xTerminate) {
        while (!xTerminate || n1car.getCarSpeed() > 90) {
            n1car.accelerate(3);// accelerating ...
            System.out.println(n1car);
            n1car.accelerate(-2);// ... decelerating
            System.out.println(n1car);
            System.out.println("\n");
            if (n1car.getCarSpeed() > 80) {
                xTerminate = true;
            }
        }
    }
    */
    //
    public static void main(String args[]) {
        // register a car
        oop102car n1car = new oop102car("CA101P","Sedan",300,0);
        //System.out.println("\n");
        System.out.println("\n" + n1car);  
        //
        //moveCar(n1car, false);
        {
        boolean xTerminate = false;
            while (!xTerminate || n1car.getCarSpeed() > 90 ) { 
                n1car.accelerate(3);// accelerating ...
                System.out.println("\n" + n1car);                
                n1car.accelerate(-2);// ... decelerating
                System.out.println(n1car);
                //System.out.println("\n");
                if (n1car.getCarSpeed() > 80) {
                    xTerminate = true;
                }
            }
        }
        //        
    }   //-end main
}   //-end public class oop102car
