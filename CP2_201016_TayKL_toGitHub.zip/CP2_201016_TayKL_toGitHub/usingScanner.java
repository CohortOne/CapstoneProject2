/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author jt
 */
import java.io.File;
import java.io.FileNotFoundException;
//import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
//
public class usingScanner {
    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        boolean xTerminate = false;
        int count;
        String str, strNext, tempStr, workStr, choiceStr;
        
        System.out.println("   FYI, String contents for processing are read from a text file.");
        try (Scanner sc = new Scanner(new File("calc.javasrc"))) {
            while (!xTerminate && sc.hasNext()) {
                System.out.println("[======= BEGINNING OF STRING PROCESSING RUNS =======]\n");
                System.out.println("The next line after '-------' contained the String contents to be processed:");
                str = sc.nextLine();
                System.out.println("-------");
                System.out.println(str);
                System.out.println("-------");
                System.out.println("\n");
                menulist(); // Display the list of processing options
                System.out.println("Please enter your menu choice:");
                //int menuNum = Integer.parseInt(System.console().readLine());
                String strOption = System.console().readLine();
                switch(strOption.toLowerCase()) {
                    case "a":
                        count=a_Process(str);
                        System.out.println("=======");// + "\n");
                        System.out.println("a.Result(s) of 'Count characters/words in this String':");
                        System.out.println(str);
                        System.out.println("a1. Word count = " + count);
                        System.out.println("a2. Character count, including <space> = " + str.length());
                        //System.out.println("\n \n");
                        break;
                    case "b":
                        System.out.println("\n");
                        System.out.println("b.Please enter your chosen word.");
                        choiceStr = System.console().readLine();
                        count=b_Process(choiceStr, str);
                        //System.out.println("\n");
                        System.out.println("=======");
                        System.out.println("b.Result(s) of 'Chosen word/character count in this String':");
                        System.out.println(str);
                        System.out.print("b.The chosen word/character " + choiceStr + " ");
                        System.out.print("has a count = " + count); 
                        System.out.println("\n");
                        break;
                    case "c":
                        strNext = sc.nextLine();
                        count=c_Process(strNext, str);
                        System.out.println("\n");
                        System.out.println(str);
                        System.out.println(strNext);
                        if (count != 0) { System.out.println("c.The Strings are different."); }
                        else { System.out.println("c.The Strings are similar."); }
                        //System.out.println("\n \n");
                        break;
                    case "d":   //d.compares two strings lexicographically, i.e. using Unicode values, ignoring case
                        strNext = sc.nextLine();
                        count=d_Process(strNext, str);
                        System.out.println("\n");
                        System.out.println(str);
                        System.out.println(strNext);
                        if (count != 0) { System.out.println("d.Ignoring case, the Strings are still different."); }
                        else { System.out.println("d.Ignoring case, the Strings are similar."); }
                        //System.out.println("\n \n");
                        break;
                    case "e":
                        System.out.println("\n");
                        System.out.println("e.Please enter your chosen word/character: ");
                        choiceStr = System.console().readLine();
                        count=e_Process(choiceStr, str);
                        System.out.println("\n");
                        System.out.println(str);
                        System.out.println("e. First occurence of chosen word/character at position " + count); 
                        //System.out.println("\n \n");
                        break;
                    case "f":
                        System.out.println("\n");
                        System.out.println("f.Please enter your chosen word/character to be removed: ");
                        choiceStr = System.console().readLine();
                        tempStr=f_Process(choiceStr, str);
                        System.out.println("\n");
                        System.out.println(str);
                        System.out.println("f. First occurence of chosen word/character removed. See line below."); 
                        System.out.println(tempStr);
                        //System.out.println("\n \n");
                        break;
                    case "g":
                        System.out.println("\n");
                        System.out.println("g.Please enter your chosen word/character to be replaced: ");
                        workStr = System.console().readLine();
                        System.out.println("g.Please enter the new replacement word/character: ");
                        choiceStr = System.console().readLine();
                        tempStr=g_Process(choiceStr, str, workStr);
                        System.out.println("\n");
                        System.out.println(str);
                        System.out.println("g.First occurence of chosen word/character replaced. See line below."); 
                        System.out.println(tempStr);
                        //System.out.println("\n \n");
                        break;
                    case "h":
                        System.out.println("\n");
                        System.out.println("h.Please enter your chosen word/character to be replaced: ");
                        workStr = System.console().readLine();
                        System.out.println("h.Please enter the new replacement word/character: ");
                        choiceStr = System.console().readLine();
                        tempStr=h_Process(choiceStr, str, workStr);
                        System.out.println("\n");
                        System.out.println(str);
                        System.out.println("h.All occurences of chosen word/character replaced. See line below."); 
                        System.out.println(tempStr);
                        //System.out.println("\n \n");
                        break;
                    case "i":
                        System.out.println("\n");
                        tempStr=i_Process(str);
                        System.out.println("\n");
                        System.out.println(str);
                        System.out.println("i. Reversed String contents displayed on the next line ..."); 
                        System.out.println(tempStr);
                        //System.out.println("\n \n");
                        break;
                    //
                    case "j": //j.Find if a string is a palindrome.
                        tempStr=i_Process(str);     // reverse the given String
                        count=d_Process(tempStr, str); // compareToIgnoreCase
                        if (count == 0) { System.out.println("j.Given String is a palindrome."); }
                        else { System.out.println("j.Given String is NOT a palindrome."); }
                        //System.out.println("You are with Operator 'j' now. Unfortunately, it is NR.");
                        wait1moment(2000);
                        break;
                    case "k": // k.Sub-string
                        System.out.println("k.Deprecated. Use option 'l' to test substring.");
                        //System.out.println("You are with Operator 'k' now. Unfortunately, it is NR.");
                        wait1moment(2000);
                        break;
                    case "l": // l.swap 2 strings without using a 3rd variable
                        strNext = sc.nextLine();
                        int len1 = str.length();
                        int len2 = strNext.length();
                        System.out.println("l. Before swapp ...");
                        System.out.println("l. 1st String: " + str);
                        System.out.println("l. 2nd String: " + strNext);
                        System.out.println("l. Swapping in progress ... ");
                        str = str + strNext;
                        strNext = str.substring(0, len1);
                        str = str.substring(len1, len2+len1);
                        System.out.println("l. After swapp ...");
                        System.out.println("l. 1st String: " + str);
                        System.out.println("l. 2nd String: " + strNext);
                        //System.out.println("You are with Operator 'l' now. Unfortunately, it is NR.");
                        wait1moment(5000);
                        break;
                    case "m": //swap 2 strings (via a 3rd variable)
                        strNext = sc.nextLine();
                        System.out.println("m. Before swapp ...");
                        System.out.println("m. 1st String: " + str);
                        System.out.println("m. 2nd String: " + strNext);
                        System.out.println("m. Swapping in progress via 3rd party ... ");
                        String str3 = str;
                        str = strNext;
                        strNext = str3;
                        System.out.println("m. After swapp ...");
                        System.out.println("m. 1st String: " + str);
                        System.out.println("m. 2nd String: " + strNext);
                        //System.out.println("You are with Operator 'm' now. Unfortunately, it is NR.");
                        wait1moment(5000);
                        break;
                    //
                    case "n":
                        System.out.println("\n");
                        System.out.println("n.Please enter your chosen word/character to flip case: ");
                        choiceStr = System.console().readLine();
                        tempStr=n_Process(choiceStr, str);
                        System.out.println("\n");
                        System.out.println(str);
                        System.out.println("n. Flip case of chosen word/character. See line below."); 
                        System.out.println(tempStr);
                        //System.out.println("\n \n");
                        break;
                    case "o":
                        System.out.println("\n");
                        System.out.println("o.Please enter your chosen word/character to flip case: ");
                        choiceStr = System.console().readLine();
                        tempStr=o_Process(choiceStr, str);
                        System.out.println("\n");
                        System.out.println(str);
                        System.out.println("o. Flip case of chosen word/character. See line below."); 
                        System.out.println(tempStr);
                        //System.out.println("\n \n");
                        break;
                    case "p":
                        System.out.println("\n");
                        System.out.println("p.Please enter your chosen word/character to flip case: ");
                        choiceStr = System.console().readLine();
                        tempStr=n_Process(choiceStr, str);
                        System.out.println("\n");
                        System.out.println(str);
                        System.out.println("p. Flip case of chosen word/character. See line below."); 
                        System.out.println(tempStr);
                        //System.out.println("\n \n");
                        break;
                    //
                    case "x":
                        System.out.println("\n \n");
                        System.out.println("Program terminated by user.");
                        System.out.println("\n \n");
                        xTerminate = true;
                        break;
                    default:
                        //System.out.println("\n \n");
                        //System.out.println("Program terminated by user.");
                        //System.out.println("\n \n");
                        //xTerminate = true;
                        //break;
                }
                System.out.print("[======= ");
                System.out.print("Menu option (" + strOption + ") ");
                System.out.print("delivered =======]\n");
                System.out.println("\n \n");
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(usingScanner.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(!xTerminate){
            System.out.println("We have come to the end of the file. Re-run the program, if necessry.");
            System.out.println("[======= STRING PROCESSING RUNS TERMINATED =======]\n");
        }
        // reading all words from file using Scanner
        /*
        System.out.println("Reading a text word by word: ");
        try (Scanner sc2 = new Scanner(new File("calc.javasrc"))) {
            while (sc2.hasNext()) {
                String word = sc2.next();
                System.out.println(word);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        */
    }
    //
    // print a blank line
    static void display() {
        System.out.println("\n");
    }
    //
    // pause the program run momentarily
    static void wait1moment(int n) throws InterruptedException {
        Thread.sleep(n);
    }
    //
    // a. Word count and Length of String 
    static int a_Process(String strA){
        int countA = 0;
        int lenA = strA.length();
        int numA = strA.lastIndexOf(" ");
        for(int i=0; i<=numA; i++){
            if((strA.substring(i,i+1).equals(" "))){
                if( i>0 && !(strA.substring(i-1,i).equals(" ")) ) {
                    countA += 1;
                }
            }
        }
        if(numA < (lenA-1)) { countA += 1; }
        return countA;
    }
    //
    // b. Count of chosen word/character
    static int b_Process(String wordStr, String lineStr){
        int countB = 0;
        int pos1st = lineStr.indexOf(wordStr);
        int posLast = lineStr.lastIndexOf(wordStr);
        if (pos1st >= 0) {
            if (posLast > pos1st) {
                do {
                    countB += 1;
                    posLast = lineStr.lastIndexOf(wordStr, posLast - 1);
                } while (posLast >= pos1st);
            } else {
                countB = 1;
            }
        }
        return countB;
    }
    //
    // c. compares two strings lexicographically, i.e. using Unicode values, case-sensitive
    static int c_Process(String wordStr, String lineStr) {
        return wordStr.compareTo(lineStr);
    }
    //
    // d. compares two strings lexicographically, i.e. using Unicode values, ignoring case
    static int d_Process(String wordStr, String lineStr) {
        return wordStr.compareToIgnoreCase(lineStr);
    }
    //
    // e. Position of first occurence of chosen word/character
    static int e_Process(String wordStr, String lineStr){
        int numE = lineStr.indexOf(wordStr);
        return numE;
    }
    //
    // f. Remove first occurence of chosen word/character
    static String f_Process(String oldStr, String lineStr){
        String strF;
        int len2G = lineStr.length();
        int len3G = oldStr.length();
        int pos3G = lineStr.indexOf(oldStr);
        if(pos3G>=0) {
            if(pos3G>0) {
                strF = lineStr.substring(0,pos3G) + lineStr.substring((pos3G+len3G),len2G);
            }
            else {
                strF = lineStr.substring(len3G,len2G);
            }
        }
        else { strF = lineStr; }
        return strF;
    }
    // g. Replace first occurrence of chosen word/character
    static String g_Process(String wordStr, String lineStr, String oldStr){
        /*
        String strG;
        int len2G = lineStr.length();
        int len3G = oldStr.length();
        int pos3G = lineStr.indexOf(oldStr);
        if(pos3G>=0){
            if(pos3G>0) {
                strG = lineStr.substring(0,pos3G) + wordStr + lineStr.substring((pos3G+len3G),len2G);
            }
            else {
                strG = wordStr + lineStr.substring(len3G,len2G);
            }
        }
        else { strG = lineStr; }
        return strG;
        */
        return lineStr.replaceFirst(oldStr, wordStr);
    }
    //
    // h.Replace ALL occurrences of oldStr with choiceStr 
    static String h_Process(String choiceStr, String lineStr, String oldStr){
        //String strH = lineStr.replaceAll(oldStr, choiceStr);
        return lineStr.replaceAll(oldStr, choiceStr);
    }    
    //
    // i.Reverse the contents in a string
    static String i_Process(String lineStr){
        String strI = "";
        int lenA = lineStr.length();
        for (int i=(lenA-1); i>=0; i--) {
            strI += lineStr.substring(i,i+1);
        }
        return strI;
    }    
    //
    // j.Find if a string is palindrome
    static void j_Process(String lineStr) {
    }
    //
    // k.Sub-string
    static void k_Process(String lineStr) {
    }
    //
    // l.swap 2 strings without using a 3rd variable
    static void l_Process(String str1, String str2) {
    }
    //
    // m.swap 2 strings (via a 3rd variable)
    static void m_Process(String lineStr) { 
    }
    //
    // n. Flip case: Lower/Upper, Upper/Lower
    static String n_Process(String wordStr, String lineStr) {
        /*
        System.out.println(Character.isLowerCase('c'));     true
        System.out.println(Character.isLowerCase('C'));     false
        System.out.println(Character.isLowerCase('\n'));    false
        System.out.println(Character.isLowerCase('\t'));    false
        String str2 = "Hello";
        for(int i=0; i<str2.length();i++){
        char ch = str2.charAt(i);
        System.out.println("Character at "+i+" Position: "+ch);
        }
        */
        //Character nChar;
        String strN = lineStr;
        String tmpWStr = wordStr.toLowerCase();
        String tmpLStr = lineStr.toLowerCase();
        char ch = lineStr.charAt(0);
        int pos1st;
        int lenWord = wordStr.length();
        int lenLine = lineStr.length();
        for (int i=0; i < lenLine; i++) {
            //char ch = lineStr.charAt(i);
            pos1st = tmpLStr.indexOf(tmpWStr, i);
            if (pos1st >= 0  && pos1st < lenLine) {
                for (int j=pos1st; j < pos1st + lenWord; j++) {
                    ch = lineStr.charAt(j);
                    if(Character.isLowerCase(ch)) {
                        //convert to UpperCase
                        if (j>0) { 
                            strN = strN.substring(0, j-1) + strN.substring(j,j+1).toUpperCase() + strN.substring(j+1,lenLine);
                        }
                        else {
                            strN = strN.substring(j,j+1).toUpperCase() + strN.substring(j+1,lenLine);
                        }
                    }
                    else {
                        //convert to LowerCase
                        if (j>0) { 
                            strN = strN.substring(0, j-1) + strN.substring(j,j+1).toLowerCase() + strN.substring(j+1,lenLine);
                        }
                        else {
                            strN = strN.substring(j,j+1).toLowerCase() + strN.substring(j+1,lenLine);
                        }
                    }                    
                }
            }
            i = i + pos1st + lenWord -1;
        }
        return strN;
    }    
    //
    // o. strOption.toLowerCase()
    static String o_Process(String choiceStr, String lineStr){
        return lineStr.replaceAll(choiceStr, choiceStr.toLowerCase());
    }    
    //
    // p. strOption.toUpperCase()
    static String p_Process(String choiceStr, String lineStr){
        return lineStr.replaceAll(choiceStr, choiceStr.toUpperCase());
    }    
    //
    // Menu of options for String Processing  
    static void menulist() {
        System.out.println("MENU options from 'a' to 'p'. Any other key to process next String contents. 'X' to exit.");
        System.out.println("-----------------------------------------------------------------------------------------");
        System.out.println("a.Count characters/words in a String. TestOK.");
        System.out.println("b.Count a specific word/character in a String. TestOK.");
        System.out.println("c.Compare 2 Strings (Unicode values), Case-sensitive. TestOK.");
        System.out.println("d.Compare 2 Strings (Unicode values), ignore Case. TestOK."); 	
        System.out.println("e.Search for the first occurrence of a word or character in a String. TestOK.");
        System.out.println("f.Remove the first occurrence of chosen character/word from a String. TestOK.");
        System.out.println("g.Replace the first occurrence of a character/word in a String. TestOK.");
        System.out.println("h.Replace all occurrences of a character/word in a String. TestOK.");
        System.out.println("i.Reverse a string. TestOK.");
        System.out.println("j.Find if a string is palindrome. Combination of 'i' + 'd' features. TestOK.");
        System.out.println("k.Sub-string. See option 'l' immediately below.");
        System.out.println("l.swap 2 strings without using a 3rd variable. TestOK.");
        System.out.println("m.swap 2 strings (via a 3rd variable). TestOK.");
        System.out.println("n.flip case: upper/lower, lower/upper. Error");
        System.out.println("o.alter case from upper to lower for ALL occurrences. TestOK.");
        System.out.println("p.alter case from lower to upper for ALL occurrences. Error? Coz 'o' worked, 'p' should too.");        
        System.out.println("x.Terminate String Processing Operations.");
        System.out.println("-----------------------------------------------------------------------------------------");
    }
}
