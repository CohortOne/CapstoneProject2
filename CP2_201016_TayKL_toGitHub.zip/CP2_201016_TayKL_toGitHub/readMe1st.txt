2020 Oct 16. CP2 closing.

1. Class Diagram.
- Practice on drawing Class Diagram.
- A box with 3 parts - Name of Class, Attributes and Methods

2. oop102car.java
- Learning getter/setter (accessor/mutator).
- Also, learned that you can include validation check(s) 
 in the setter method.

3. usingScanner.java
- Learning String manipulations.
- Also, learn to read from a text file ("calc.javasrc")
 using Scanner.

4. dnT.java
- Learning Date and Time processing and formatting.

5. ABankAcct.java
- Learning to create write a text file ("ABankFile.txt").
- Learning to append (records) to a text file ("ABankFile.txt").
- java.nio.*
- Added public static Scanner readInput = new Scanner(System.in); //setup for IDE console inputs
 and inputString = readInput.nextLine();
 
Open actions.
a. Enum operations.
b. Use of getter/setter in conjunction with file IOs.
c. Use of sorted Array as index to a text file containing
 list of records. 





