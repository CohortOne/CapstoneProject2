
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package com.oop;

//import java.time.*;
import java.time.DayOfWeek;
//import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.Year;
import java.time.ZoneId;
//import static java.time.ZoneId.systemDefault;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.time.format.TextStyle;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
//

/**
 *
 * @author jt
 */
public class dnT {
    //
    //g.calculate the day of week based on a given date
    static String g_dayOfWeekText(LocalDate date, Locale locale) {
        DayOfWeek day = date.getDayOfWeek();
        return day.getDisplayName(TextStyle.FULL, locale);
    }
    //
    // In general, a year is a leap year if it is divisible by four without remainder. 
    // However, years divisible by 100, are not leap years, 
    // with the exception of years divisible by 400 which are.
    // For example, 1904 is a leap year it is divisible by 4. 
    // 1900 was not a leap year as it is divisible by 100, 
    // however 2000 was a leap year as it is divisible by 400.
    //d.Check if a given year is leap year.
    static boolean d_leapYear(int year) {
        boolean isLeapYear;
        // divisible by 4
        isLeapYear = (year % 4 == 0);
        // divisible by 4 and not 100
        isLeapYear = isLeapYear && (year % 100 != 0);
        // divisible by 4 and not 100 unless divisible by 400
        isLeapYear = isLeapYear || (year % 400 == 0);
        return isLeapYear;
    }
    //
    //
    static boolean dateIsValid(String dateStr, DateTimeFormatter dateFormatter) {
        LocalDate date = null;
        try {
            date = LocalDate.parse(dateStr, dateFormatter);
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }
    //
    //
    public static LocalDate vetAndParseDate(String dateStr, DateTimeFormatter dateFormatter) 
    {
        LocalDate date = null;
        try {
            date = LocalDate.parse(dateStr, dateFormatter);
        } catch (DateTimeParseException e) {
        }
        return date;
    }
    //
    //
    public static void main(String[] args) throws InterruptedException {
        LocalDate dateLocal, anyDate;
        LocalDateTime currentDateTime;
        ZoneId zoneId;
        ZonedDateTime zonedDateTime;
        Period periodBetween;

        String dateFormat = "uuuu-MM-dd";
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(dateFormat)
                                            .withResolverStyle(ResolverStyle.STRICT);
        //
        String inputString, printString;
        boolean xTerminate = false;
        while (!xTerminate) {
            System.out.println("\n");
            //checking out parsing a String containing date value
            anyDate = vetAndParseDate(LocalDate.now().toString(), dateFormatter);
            System.out.println("Today is " + anyDate);
            System.out.println("[======= BEGINNING OF Date and Time Operations =======]\n");
            menulist(); // Display the list of processing options
            System.out.println("Please enter your menu choice:");
            String strOption = System.console().readLine();
            switch (strOption.toLowerCase()) {
                case "a": //a.Get Current Date and Time
                    currentDateTime = LocalDateTime.now();
                    printString = "Current date and time is : " 
                            + currentDateTime.format(DateTimeFormatter.ofPattern("dd MMM, uuuu HH:mm:ss"));
                    displayString(printString);
                    wait1moment(1000);
                    break;
                //
                case "b": //b.Difference (java.time.temporal.ChronoUnit) between two given dates in nanoseconds
                    LocalDateTime curr1DateTime = LocalDateTime.now().minusSeconds(3);
                    zoneId = ZoneId.of("America/New_York");
                    ZonedDateTime curr2DateTime = LocalDateTime.now().plusDays(1).atZone(zoneId);
                    long duration;
                    //duration = Duration.between(currentDateTime, curr2DateTime).getNano();
                    //duration = Duration.between(curr1DateTime, curr2DateTime).getSeconds();
                    duration = ChronoUnit.SECONDS.between(curr1DateTime, curr2DateTime);
                    printString = "Start Date and Time is " + curr1DateTime.format(DateTimeFormatter.ofPattern("dd MMM, uuuu HH:mm:ss"));
                    displayString(printString);
                    printString = "End Date and Time is " + curr2DateTime.format(DateTimeFormatter.ofPattern("dd MMM, uuuu HH:mm:ss"));
                    displayString(printString);
                    printString = "Difference between the Start and End is : " + duration + " seconds.";
                    displayString(printString);
                    wait1moment(1000);
                    break;

                //
                case "c": //c.Get the days (Period) Between Two Dates.
                    LocalDate any1Date, any2Date;
                    System.out.println("Please enter date1 in YYYY-MM-DD style:");
                    inputString = System.console().readLine();
                    if ("".equals(inputString)) {
                        any1Date = LocalDate.now().plusDays(3);
                    } else {
                        if(dateIsValid(inputString, dateFormatter)) {
                            any1Date = LocalDate.parse(inputString);
                        }
                        else {
                            System.out.println("Input date in YYYY-MM-DD style. Try menu option 'c' again.");
                            wait1moment(750);
                            break;
                        }
                    }
                    System.out.println("Please enter date2 in YYYY-MM-DD style:");
                    inputString = System.console().readLine();
                    if ("".equals(inputString)) {
                        any2Date = LocalDate.now().plusWeeks(3);
                    } else {
                        if(dateIsValid(inputString, dateFormatter)) {
                            any2Date = LocalDate.parse(inputString);
                        }
                        else {
                            System.out.println("Input date in YYYY-MM-DD style. Try menu option 'c' again.");
                            wait1moment(750);
                            break;
                        }
                    }
                    periodBetween = Period.between(any1Date, any2Date);
                    printString = "The Period between " + any1Date
                            + " and " + any2Date
                            + " is " + periodBetween.getYears() + " years, "
                                     + periodBetween.getMonths() + " months,"
                            + " and " + periodBetween.getDays() + " days.";
                    displayString(printString);
                    wait1moment(1000);
                    break;
                //
                case "d": //d.Check if a given year is leap year.
                    int yearInput;
                    System.out.println("Please enter the Year number to verify:");
                    inputString = System.console().readLine();
                    if ("".equals(inputString)) {
                        yearInput = LocalDate.now().minusYears(3).getYear();
                    } else {
                        if(inputString.matches("[0-9]+")) {
                           yearInput = Integer.parseInt(inputString);
                        }
                        else {
                            System.out.println("Input whole numbers only. Try menu option 'd' again.");
                            wait1moment(750);
                            break;
                        }                       
                    }
                    // using java.time.Year.isLeap() method
                    boolean isLeapYear = Year.isLeap(yearInput); 
                    // using custom method d_leapYear
                    //boolean isLeapYear = d_leapYear(yearInput);
                    if (isLeapYear) {
                        printString = "Given year number " + yearInput
                                + " is a Leap Year.";
                    } else {
                        printString = "Given year number " + yearInput
                                + " is NOT a Leap Year.";
                    }
                    displayString(printString);
                    wait1moment(1000);
                    break;
                //
                case "e": //e.convert date to EST/EDT timezone  
                    ZonedDateTime localZoneDT = ZonedDateTime.of(LocalDateTime.now(), ZoneId.systemDefault());
                    ZonedDateTime otherZoneDT = localZoneDT.withZoneSameInstant(ZoneId.of("Australia/Darwin"));
                    zoneId = ZoneId.of("America/New_York");
                    printString = "Current local date & time is " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd MMM, uuuu HH:mm"))
                            + "\n"
                            + " which is " + LocalDateTime.now().atZone(zoneId).format(DateTimeFormatter.ofPattern("MMM dd, uuuu h.mm a z")) 
                            + " in " + zoneId ;
                    displayString(printString);
                    wait1moment(1000);
                    break;
                //
                case "f": //f.calculate the age of a person based on Date of Birth
                    System.out.println("Please enter the DoB in YYYY-MM-DD style:");
                    inputString = System.console().readLine();
                    if ("".equals(inputString)) {
                        anyDate = LocalDate.now().minusDays(1);
                    } else {
                        if(dateIsValid(inputString, dateFormatter)) {
                            anyDate = LocalDate.parse(inputString);
                        }
                        else {
                            System.out.println("Input date in YYYY-MM-DD style. Try menu option 'f' again.");
                            wait1moment(750);
                            break;
                        }
                    }
                    Period age = Period.between(anyDate, LocalDate.now());
                    printString = "Whoever is " + age.getYears() + " years, "
                            + age.getMonths() + " months, and "
                            + age.getDays() + " days old,"
                            + " please stand up.";
                    displayString(printString);
                    wait1moment(1000);
                    break;
                //
                case "g": //g.calculate the day of week based on a given date    
                    System.out.println("Please enter any date in YYYY-MM-DD style:");
                    inputString = System.console().readLine();
                    if ("".equals(inputString)) {
                        anyDate = LocalDate.now().plusDays(3);
                    } else {
                        if(dateIsValid(inputString, dateFormatter)) {
                            anyDate = LocalDate.parse(inputString);
                        }
                        else {
                            System.out.println("Input date in YYYY-MM-DD style. Try menu option 'g' again.");
                            wait1moment(750);
                            break;
                        }
                    }
                    String dayOfWeek = g_dayOfWeekText(anyDate, Locale.getDefault());
                    printString = "The date " + anyDate
                            + " is a " + dayOfWeek;
                    displayString(printString);
                    wait1moment(1000);
                    break;
                //
                case "h": //h.Display a every date with 30 Days Interval for the next two years (24 months, 4 rows x 6 columns)
                    LocalDate today = LocalDate.now();
                    System.out.println("Today is " + today.format(DateTimeFormatter.ofPattern("dd MMM, uuuu")));
                    int daysNum = 0;
                    for (int row = 1; row < 5; row++) { //table row-wise, 4 rows
                        System.out.print("  ");
                        for (int col = 1; col < 7; col++) { //table column-wise, 6 columns
                            daysNum += 30; 
                            System.out.print(today.plusDays(daysNum).format(DateTimeFormatter.ofPattern("dd-MM-uuuu")) + "\t");                                              
                        }
                        System.out.print("\n");
                    }
                    wait1moment(2000);
                    break;
                //
                case "x":
                    xTerminate = true;
                    break;
                default:
                    break;
            }
        }
        //
    }   //-End main
    //
    // print String contents
    static void displayString(String s) {
        System.out.println("\n" + s + "\n");
    }
    //
    // print a blank line
    static void display() {
        System.out.println("\n");
    }
    //
    // pause the program run momentarily
    static void wait1moment(int n) throws InterruptedException {
        Thread.sleep(n);
    }
    //
    // Menu options list
    static void menulist() {
        System.out.println("MENU options from 'a' to 'h'. 'X' to exit.");
        System.out.println("-----------------------------------------------------------------------------------------");
        System.out.println("a.Get Current Date and Time. TestOK");
        System.out.println("b.Difference (java.time.temporal.ChronoUnit) between two given dates. TestOK");
        System.out.println("c.Get the days (Period) Between Two Dates. TestOK");
        System.out.println("d.Check if a given year is leap year. TestOK"); 	
        System.out.println("e.Convert date to ET timezone. TestOK");
        System.out.println("f.Calculate the age of a person based on Date of Birth. TestOK");
        System.out.println("g.Calculate the day of week based on a given date. TestOK");
        System.out.println("h.Display a every date with 30 Days Interval for the next two years (24 months, 4 rows x 6 columns). TestOK");
        System.out.println("x.Terminate String Processing Operations.");
        System.out.println("-----------------------------------------------------------------------------------------");
    }
    //
}   //-End public class

/*
Projects for today's PM session 201009, Lab1
============================================

Date and Time [java.time.*]
===========================
Get Current Date and Time
Difference between two given dates.
Get the days Between Two Dates
Check if a given year is leap year or not?
convert date to EST/EDT timezone
calculate the age of a person based on Date of Birth 
calculate the day of week based on a given date 
Display a every date with 30 Days Interval for the next two years

*/
