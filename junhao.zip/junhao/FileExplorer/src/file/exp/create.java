/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file.exp;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

/**
 *
 * @author hlaing
 */
public class create {
    
    
    public static String fileName = "";

    /**
     *
     */
    public static Scanner myObj = new Scanner(System.in);

    public static void main(String[] args)throws Exception {
      File f = new File("C:\\Users\\hlaing\\Desktop\\New folder\\io\\FileExplorer\\TestFolder\\"); 
    if (f.exists()) {
            System.out.print(" Enter file name to create");
            fileName = myObj.nextLine();
            System.out.println(" File Name Entered is : " + fileName);
            File newF = new File(f.getAbsolutePath() + "\\" + fileName);
            if (newF.exists()) {
                System.out.println(" File already exists");
                System.exit(0);
            }
            if (newF.createNewFile()) {
                System.out.println(" File Created with the following details ");
            
                
                try (FileWriter fw = new FileWriter(newF)
                //new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
                ) {
                    System.out.println(" Enter File Content [quit] to stop");
                    String newLine = "";
                    do {
                        
                        fw.write(newLine + "\n");
                        newLine = myObj.nextLine();
                        
                    } while (!newLine.equals("quit"));
                }
                System.out.println(" display the file contents [Y/N] ");
                String resp = myObj.nextLine();
                if (resp.equals("Y") || resp.equals("y")) {
                    try (FileReader fr = new FileReader(newF)) {
                        int i = 0;
                        while ((i = fr.read()) != -1) {
                            System.out.print((char) i);
                        }
                    }
                }
            }
    }
    }
}

        
    
    



