/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file.exp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Scanner;

/**
 *
 * @author hlaing
 */
public class binputst {
         public static String fileName = "";
         public static File file;

    /**
     *
     */
    public static Scanner myObj = new Scanner(System.in);

    public static void main(String[] args)throws Exception {
      File f = new File("C:\\Users\\hlaing\\Desktop\\New folder\\io\\FileExplorer\\TestFolder\\"); 
   if (f.exists()) {
                System.out.print(" Enter file name to create ");
                fileName = myObj.nextLine();
                System.out.println(" File Name Entered is : " + fileName);
                file = new File(f.getAbsolutePath() + "\\" + fileName);
                if (file.exists()) {
                    System.out.println(" File already exists");
                    System.exit(0);
                }
                if (file.createNewFile()) {
                   FileOutputStream is = new FileOutputStream(file);
                   BufferedOutputStream bis = new BufferedOutputStream(is);
                    System.out.println(" Enter File Content [quit] to stop");
                    String newLine = "";
                    do {
                        bis.write((newLine + "\n").getBytes());
                        newLine = (myObj.nextLine());
                    } while (!(newLine.equals("quit")));
                    bis.flush();
                    bis.close();
                    //bw.flush();
                    //bw.close();
                    //fw.close();
                    System.out.print(" display the file contents [Y/N] : ");
                    String resp = myObj.nextLine();
                    if (resp.equals("Y") || resp.equals("y")) {
                        FileInputStream ips = new FileInputStream(file);
                        BufferedInputStream bs = new BufferedInputStream(ips);
                        int i = bs.read();
                        while (i != -1) {
                            System.out.print((char) i);
                            i = bs.read();
                        }
                        bs.close();
                      // br.close();
                       //fr.close();

                    }
                }
            }
     
        
    }
}


