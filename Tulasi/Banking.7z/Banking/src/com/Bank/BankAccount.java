package com.Bank;

import java.util.Objects;


public class BankAccount {
    
      
 String accType;
 int accNo;
 String accName;
 double balance;
 int amount;
 

    public BankAccount(String accType, int accNo, String accName, double initialBalance) {
        this.accType = accType;
        this.accNo = accNo;
        this.accName = accName;
        this.balance = initialBalance;
          //System.out.println("Four-Argument Constructor");
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.accType);
        hash = 89 * hash + Objects.hashCode(this.accName);
        hash = 89 * hash + Objects.hashCode(this.balance);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final BankAccount other = (BankAccount) obj;
        if (!Objects.equals(this.accType, other.accType)) {
            return false;
        }
        if (!Objects.equals(this.accName, other.accName)) {
            return false;
        }
        if (!Objects.equals(this.balance, other.balance)) {
            return false;
        }
        return true;
    }


    @Override
    public String toString() {
        return "BankAccount{" + "accType=" + accType + ", accNo=" + accNo + ", accName=" + accName + ", balance=" + balance + '}';
    }
    
       


    public String getAccType() {
        return accType;
    }

    public void setAccType(String accType) {
        this.accType = accType;
    }

    public int getAccNo() {
        return accNo;
    }

    public void setAccNo(int accNo) {
        this.accNo = accNo;
    }

    public String getAccName() {
        return accName;
    }

    public void setAccName(String accName) {
        this.accName = accName;
    }
        
     
     //Deposit Money into the bank account
    public void deposit(double amount){
        
        double newbalance = balance + amount;
        balance = newbalance;
    }
    //withdraw amount
   public void withdraw(double amount) {
       
       double newbalance = balance - amount;
        balance = newbalance;
   }
   
   //get the current balance
   public double getBalance(){
       
       return balance;
   }
   //Transfer funds from patent account to junior account
   
   public void transferfunds(BankAccount junior, double amount){
       
     junior.deposit(amount);
      this.withdraw(amount);
   }
  }
  