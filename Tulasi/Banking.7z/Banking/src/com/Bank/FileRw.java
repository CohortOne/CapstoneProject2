package com.Bank;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class FileRw {

    public static String filename = "";
    public static Scanner str = new Scanner(System.in);
    Scanner scanner = new Scanner(System.in);
 
     
    public static void main(String args[]) throws IOException {

        try {
            File f = new File("C:\\Capstone\\OOPS\\Banking");

            if (f.exists()) {

                System.out.print("Enter file name to create and then write to it :: ");
                filename = str.nextLine();
                System.out.println("File Name Entered is : " + filename);
                File newf = new File(f.getAbsolutePath() + "\\" + filename);
                if (newf.exists()) {
                    System.out.println("File already exists");
                    System.exit(0);

                }
              
                if (newf.createNewFile()) {
                    System.out.println("File Created with the following details ");
                System.out.println(newf.getName());
                System.out.println(newf.getParent());
                System.out.println("Is this a file " + newf.isFile());
                System.out.println(newf.getAbsolutePath());
                System.out.println(newf.getAbsoluteFile());
                System.out.println(newf.canWrite());
                System.out.println(newf.getFreeSpace());                
                System.out.println(newf.canRead());
                System.out.println(newf.canExecute());
                System.out.println(newf.delete());
                    FileWriter fw = new FileWriter(newf);
                    System.out.println("Enter File Content [quit] to stop ");
                    String newLine = " ";
                    do {

                        fw.write(newLine + "\n");
                        newLine = str.nextLine();
                    } while (!newLine.equals("quit"));
                    fw.close();
                    System.out.println("you want to display content [Y/N");
                    String resp = str.nextLine();
                    if (resp.equals("Y") || resp.equals("yes")) {
                        FileReader fr = new FileReader(newf);

                        int i = 0;
                        while ((i = fr.read()) != -1) {
                            System.out.print((char) i);
                        }
                       
                       System.out.println("you want to delete the file [Y/N");
                       String del = str.nextLine();
                       FileWriter df = new FileWriter(newf);
                       if(newf.delete()) {
                            System.out.println(newf.getName() + " is deleted!");
                       } else {
                          System.out.println("Delete operation is failed.");
                         
                    }
                    } 

                    
                }

            }

        } catch (Exception e) {

        }
    }
}
