
package com.Bank;

import java.util.Scanner;


public class MainClass {
            
     
    
    public static void main(String[] args) {
        
       
       
    BankAccount acc1 = new BankAccount("SA", 1002, "Jackson", 500);
        BankAccount acc2 = new JuniorAccount("Active", "JA", 13, 1001, "Joseph", 100);
        JuniorAccount stAcc = new JuniorAccount("Active", "JA", 13, 1001, "Joseph", 100);

        if (acc1.equals(acc2)) {
            System.out.println(" Same Accounts " + acc1);
        } else {
            System.out.println(" Different Accounts ");

        }

        System.out.printf("Account #%s has initial balance of $%.2f%n",
                acc1.getAccNo(), acc1.getBalance());
        System.out.printf("Account #%s has initial balance of $%.2f%n",
                acc2.getAccNo(), acc2.getBalance());

        //for deposit
        acc1.deposit(50);

        System.out.printf("Account #%s has initial balance of $%.2f%n",
                acc1.getAccNo(), acc1.getBalance());
        System.out.printf("Account #%s updated balance $%.2f%n",
                acc2.getAccNo(), acc2.getBalance());

        System.out.printf(acc2.getAccName());
        System.out.println(stAcc.getAge());

        stAcc.withdraw(50);
        // stAcc.transferfunds(acc2, 100);
        System.out.println(stAcc.getAccstatus());

    }
}


