
package com.Bank;

public class JuniorAccount extends BankAccount {

       
    String accstatus;
    String accType;
   int age;
    private float OD;

    public JuniorAccount(float OD, String accType, int accNo, String accName, double initialBalance) {
        super(accType, accNo, accName, initialBalance);
        this.OD = OD;
    }

    public String getAccstatus() {
        return accstatus;
    }

    public float getOD() {
        return OD;
    }

    public void setOD(float OD) {
        this.OD = OD;
    }

    public void setAccstatus(String accstatus) {
         if (balance >= 100) {
	    	  System.out.println("The Savings Account is still active (>=$100).");
	      } else {
	    	  System.out.println("The Savings Account is inactive (<$100)");
	    	  System.out.println("Please make a deposit such that the balance is over $100 to reactivate");
	      }
        this.accstatus = accstatus;
    }

    @Override
    public String getAccType() {
        return accType;
    }

    @Override
    public void setAccType(String accType) {
        this.accType = accType;
    }

    public int getAge() {
        return age;
    }

    /**
     *
     * @param accstatus
     * @param accType
     * @param age
     * @param accType
     * @param accNo
     * @param accName
     * @param balance
     */
    public JuniorAccount(String accstatus, String accType, int age, int accNo, String accName, double balance) {
        super(accType, accNo, accName, balance);
        this.accstatus = accstatus;
        this.accType = accType;
        this.age = age;
    }

     public void setAge(int age) {
        this.age = age;
    }

    
    public int getAccNo() {
        return accNo;
    }

    public void setAccNo(int accNo) {
        this.accNo = accNo;
    }

    public String getAccName() {
        return accName;
    }

    public void setAccName(String accName) {
        this.accName = accName;
    }

    @Override
    public void transferfunds(BankAccount junior, double amount) {
        super.transferfunds(junior, amount); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double getBalance() {
        return super.getBalance(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void withdraw(double amount) {
       /* if (amount < 0) {
            System.out.println("Sorry, you can not withdraw a negative amount, if you wish to withdraw money please use the withdraw method");
        } else if (balance - amount < -getOD()) {
            System.out.println("Sorry, this withdrawal would exceed the overdraft limit");
        }*/
       if(age <= 18) {
         System.out.println("sorry..you can not have access to withdraw amount from this account");
     } else {
          double newbalance = balance - amount;
        System.out.println("withdraw Successful");
     }
    }
    
    @Override
    public void deposit(double amount) {
        super.deposit(amount); //To change body of generated methods, choose Tools | Templates.
    }

  
 
    
}
