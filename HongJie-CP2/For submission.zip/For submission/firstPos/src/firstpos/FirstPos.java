
package firstpos;

import java.util.Scanner;


public class FirstPos {

  
    public static void main(String[] args)  {
        
        Scanner in = new Scanner(System.in);
        System.out.println("Enter Strings below ");
        String word = in.nextLine();
        System.out.println("Enter position of string to display");
        int index = in.nextInt();
        
        
       System.out.println("The char at index " + index + " is " + word.charAt(index-1));
           }

    }
    // Unable to account for spaces within a string.

