/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fibonacci;

import java.util.Scanner;

/**
 *
 * @author AhJayz85
 */


public class Fibonacci {

    public static void main(String[] args) {
        System.out.println("Enter number to display fibonacci series");
        Scanner in = new Scanner(System.in);

        
        int n = in.nextInt(), t1 = 0, t2 = 1;
        System.out.print("First " + n + " terms: ");

        for (int i = 1; i <= n; ++i)
        {
            System.out.print(t1 + " + ");

            int sum = t1 + t2;
            t1 = t2;
            t2 = sum;
        }
    }
}


 