
package countchar;

import java.util.Scanner;

public class Countchar {

    
    public static void main(String[] args) {
        
      System.out.println("Enter any text or number");
     
      Scanner in = new Scanner(System.in);
      
        String string = in.nextLine();    
        int count = 0;    
        
        for(int i = 0; i < string.length(); i++) {    
            if(string.charAt(i) != ' ')    
                count++;    
        } 
        System.out.println("No. of chars in string: " + count); 
    }
    
}
