
package occurstring;

import java.util.Scanner;


public class OccurString {

    
    public static void main(String[] args) {
        
    Scanner in = new Scanner(System.in);
    
    System.out.println("Enter text below");
    String str = in.nextLine();
    System.out.println("The string is: " + str);
    
    String word = in.nextLine();
    String temp[] = str.split(" ");
    int countword = 0;
    
    for (int i = 0; i < temp.length; i++) {
    if (word.equals(temp[i]))
    countword++;
    }
    
    System.out.println("The word " + word + " occurs " + countword + " times in the above string");
    
  
    
    
    }
}
        
    
    

