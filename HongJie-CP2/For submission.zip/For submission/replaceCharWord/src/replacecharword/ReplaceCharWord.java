
package replacecharword;

import java.util.Scanner;

public class ReplaceCharWord {

    static Scanner in = new Scanner(System.in);
  
    public static void main(String[] args) {
        
        System.out.println("Enter Strings:");
        String str = in.nextLine();    //user input for any strings
        String str2 = "i ate a banana";
        System.out.println("Enter Word:");
        String word = in.nextLine();       //user input for specific word
        
        String newStr = str.replaceFirst(str2, word);
        System.out.println("The new sentence is: " + newStr);
    }
    
}
