
package dbsaccounts;

/**
 *
 * @author AhJayz85
 */
public class WithinDbs  {
    DbsAccount acc1 = new DbsAccount();
}
