
package dbsaccounts;

import java.util.Objects;


public class DbsAccounts {
    
    protected String AccHolder;     //THE STATES OF DBSACCOUNT
    protected int AccNo;
    protected int AccBal;
    protected String AccType;
    

    public DbsAccounts(String AccHolder, int AccNo, int AccBal, String AccType) {    // CONSTRUCTORS
        this.AccHolder = AccHolder;
        this.AccNo = AccNo;
        this.AccBal = AccBal;
        this.AccType = AccType;
       
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.AccHolder);
        hash = 71 * hash + this.AccNo;
        hash = 71 * hash + this.AccBal;
        hash = 71 * hash + Objects.hashCode(this.AccType);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final DbsAccounts other = (DbsAccounts) obj;
        return true;
    }

    public String getAccHolder() {             // GETTER AND SETTER STARTS FROM HERE
        return AccHolder;                      // Function of Getter/setter is to gain access to
    }                                          // private variables via a method access

    public void setAccHolder(String AccHolder) {
        this.AccHolder = AccHolder;
    }

    public int getAccNo() {
        return AccNo;
    }

    public void setAccNo(int AccNo) {
        this.AccNo = AccNo;
    }

    public int getAccBal() {
        return AccBal;
    }

    public void setAccBal(int AccBal) {
        this.AccBal = AccBal;
    }

    public String getAccType() {
        return AccType;
    }

    public void setAccType(String AccType) {
        this.AccType = AccType;
    }
    DbsAccounts(){  
    }

    @Override                                            // CREATING A NEW TOSTRING TO OVERRIDE THE DEFAULT TOSTRING 
    public String toString() {                          // WHICH REFERENCE THE OBJECT ADDRESS INSTEAD OF VALUE
        return "DbsAccounts{" + "AccHolder=" + AccHolder + ", AccNo=" + AccNo + ", AccBal=" + AccBal + ", AccType=" + AccType + '}';
    }
    
    
    public static void main(String[] args) {
        DbsAccounts newClient = new DbsAccounts();
        System.out.println(newClient.hashCode());
    }
    
}
