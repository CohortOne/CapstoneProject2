package firstposword;

import java.util.Scanner;

public class FirstPosWord {

   static Scanner in = new Scanner(System.in);
   
    public static void main(String[] args) {
        
       
        System.out.println("Enter Strings:");
        String string = in.nextLine();    //user input for any strings
        System.out.println("Enter Word:");
        String word = in.nextLine();       //user input for specific word
    
        if (string.contains(word)) {
        String[] stringWords = string.split(" "); //to split main string  into sub strings
        
        for (int i = 0; i < stringWords.length; i++) {  // algorithm to provide the position of word in string.
        if (stringWords[i].toLowerCase().equalsIgnoreCase(word)) {  //flawed --- unable to rectify CASES
            var j=i+1;
            System.out.println(word + " is located as the: " + j + "th string");
                }
            }
        }
    }    
}

