/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorial;

import java.util.Scanner;
/**
 *
 * @author AhJayz85
 */
public class Factorial {


   public static void main(String args[])
   {
      int n, c, result = 1;

      System.out.println("Enter number to calculate factorial");
      Scanner in = new Scanner(System.in);

      n = in.nextInt();

      if ( n < 0 )
         System.out.println("Number should not be negative.");
      else
      {
         for ( c = 1 ; c <= n ; c++ )
            result = result*c;

         System.out.println("Factorial of "+n+" is = "+result);
      }
   }
}