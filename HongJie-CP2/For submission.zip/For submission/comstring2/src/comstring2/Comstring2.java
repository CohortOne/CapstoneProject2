/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comstring2;

import java.util.Scanner;

public class Comstring2 {

   
    public static void main(String[] args) {
      Scanner in = new Scanner(System.in);
      
      
      System.out.println("Enter First String");
      String str1 = in.nextLine();
      System.out.println("Enter Second String");
      String str2 = in.nextLine();
      if (str1.compareToIgnoreCase(str2)==0) 
      {
      System.out.println("Strings matched");
      }
      else if ((str1.compareToIgnoreCase(str2) < 0) || (str1.compareTo(str2) > 0) )
      {
      System.out.println("Strings dont matched");
      }   
    }
}