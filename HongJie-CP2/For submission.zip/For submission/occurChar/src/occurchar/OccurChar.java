
package occurchar;

import java.util.Scanner;


public class OccurChar {


    public static void main(String[] args) {
   
        Scanner in = new Scanner(System.in);
        
            System.out.println("Enter text below");
            String str = in.nextLine();
            System.out.println("The string is: " + str);
    
            char chars = in.next().charAt(0);
            int countchar = 0;
    
                for (int i = 0; i < str.length(); i++) {
                if (str.charAt(i) == chars)
                countchar++;
    
                } 
            System.out.println("The char " + chars + " occured " + countchar + " times in the above string");
    }
 }
    

