package datetime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
 import java.util.Scanner;

public class DateDiff {
    
    static Scanner in = new Scanner(System.in);
    
    public static void main(String[] args) throws ParseException {
      
        int x = 10;
        int y = 20;
        
        if(x < y){ 
        System.out.println(X is smaller)};
            
        
        
        
    }
}
