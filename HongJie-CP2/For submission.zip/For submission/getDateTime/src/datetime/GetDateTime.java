package datetime;

import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;  

public class GetDateTime {
    
   
    public static void main(String[] args) {
        
        DateTimeFormatter showDT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");  
        LocalDateTime now = LocalDateTime.now();  
        System.out.println(showDT.format(now));  
    }
}


