
package delchar;

import java.util.Scanner;

public class DelChar {

    static Scanner in = new Scanner(System.in);
    
    public static void main(String[] args) {
        
        StringBuffer sb = new StringBuffer("");  
          
        System.out.print("enter your string value: ");  
        Scanner sc = new Scanner(System.in);  
        sb.append(sc.nextLine());  
          
        System.out.print("enter index: ");  
        int index = sc.nextInt();   
         
        // deleting the character at input index  
        System.out.println("after deleting resultant string: "+sb.deleteCharAt(index-1));  
        sc.close();  
    }  
}  

