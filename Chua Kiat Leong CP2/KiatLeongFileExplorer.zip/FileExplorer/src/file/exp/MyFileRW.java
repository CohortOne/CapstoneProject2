package file.exp;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class MyFileRW {

    public static String fileName = "";

    public static Scanner myObj = new Scanner(System.in);

    public static void fileReadandWrite() {
        try {
            File f = new File("D:\\Netbeans\\InstructorFiles\\FileExplorer\\MyTestFolder"); // working directory - all my operation henceforth will happen here....
            //  Fixed path at the start of the program 
            if (f.exists()) {
                System.out.print(" Enter file name to create and then write to it :: ");
                fileName = myObj.nextLine();
                System.out.println(" File Name Entered is : " + fileName);
                File newF = new File(f.getAbsolutePath() + "\\" + fileName);
                if (newF.exists()) {
                    System.out.println(" File already exists");
                    //System.exit(0);
                }
                if (newF.createNewFile()) {
                    System.out.println(" File Created with the following details ");
                    System.out.println(newF.getName());

                    FileWriter fw = new FileWriter(newF);
                    BufferedWriter bw = new BufferedWriter(fw);
                    //new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();

                    System.out.println(" Enter File Content [quit] to stop");
                    String newLine = "";
                    do {
                        bw.write(newLine + "\n");
                        newLine = myObj.nextLine().toLowerCase();

                    } while (!newLine.equals("quit"));
                    bw.flush();
                    bw.close();
                    fw.close();
                    System.out.println(" Do you want to display the file contents [Y/N] ");
                    String resp = myObj.nextLine();
                    if (resp.equals("Y") || resp.equals("y")) {
                        FileReader fr = new FileReader(newF);
                        BufferedReader br = new BufferedReader(fr);

                        String line = br.readLine();
                        while (line != null) {
                            System.out.println(line);
                            line = br.readLine();
                        }
                        br.close();
                        fr.close();
                    }
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
            // handle - understand the exception
            // do corrective measures 
            // but no then 
            // at least log it 

        }
    }

    public static void fileRead() {
        try {
            File f = new File("D:\\Netbeans\\InstructorFiles\\FileExplorer\\MyTestFolder"); // working directory - all my operation henceforth will happen here....
            //  Fixed path at the start of the program 
            if (f.exists()) {
                System.out.print(" Enter file name to create and then write to it :: ");
                fileName = myObj.nextLine();
                System.out.println(" File Name Entered is : " + fileName);
                File newF = new File(f.getAbsolutePath() + "\\" + fileName);
                if (newF.exists()) {
                    FileReader fr = new FileReader(newF);
                    BufferedReader br = new BufferedReader(fr);

                    String line = br.readLine();
                    while (line != null) {
                        System.out.println(line);
                        line = br.readLine();
                    }
                    br.close();
                    fr.close();
                } else if (!newF.exists()) {
                    System.out.println(" File does not exist");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    public static void copyFile(String rootPath) {
        {
            FileInputStream instream = null;
            FileOutputStream outstream = null;

            try {
                System.out.print(" Enter file name to copy(do include the file type like .txt) :: ");
                fileName = myObj.nextLine();
                System.out.println(" File Name Entered is : " + fileName);
                File infile = new File(rootPath + "\\" + fileName);
                File outfile = new File(rootPath + "\\" + "CopyOf" + fileName);

                instream = new FileInputStream(infile);
                outstream = new FileOutputStream(outfile);

                byte[] buffer = new byte[1024];

                int length;
                /*copying the contents from input stream to
    	     * output stream using read and write methods
                 */
                while ((length = instream.read(buffer)) > 0) {
                    outstream.write(buffer, 0, length);
                }

                //Closing the input/output file streams
                instream.close();
                outstream.close();

                System.out.println("File copied successfully!!");

            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }

    public static void deleteFile(String rootPath) {

        System.out.print(" Enter file/folder name to delete(do include the file type like .txt) :: ");
        fileName = myObj.nextLine();
        System.out.println(" File/Folder Name Entered is : " + fileName);
        File f = new File(rootPath+ "\\" + fileName);
        if (f.delete()){
            System.out.println("File/Folder is deleted!");
        }else{
            System.out.println("Failure to delete file..");
        }

    }
    
    public static void renameFile(String rootPath){
        
        System.out.print(" Enter file/folder name to rename(do include the file type like .txt) :: ");
        fileName = myObj.nextLine();
        System.out.println(" File/Folder Name Entered is : " + fileName);
        File f = new File(rootPath+ "\\" + fileName);
        System.out.print(" What do you want to rename to(do include the file type like .txt) :: ");
        String newfileName = myObj.nextLine();
        File fn = new File(rootPath+ "\\" + newfileName);
        if (f.renameTo(fn)){
            System.out.println(" New File/Folder Name is : " + newfileName);
        }else{
            System.out.println(" Renaming has failed.");
        }                
    }
        

}
