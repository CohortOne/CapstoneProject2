/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package file.exp;

import java.io.File;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author KCHUA
 */
public class MyFolderCC {

    public static int iteration = 1;
    
    public static void createFolder(String rootPath) {
        
        System.out.println("Type in new folder name to create in current directory.");
        Scanner obj = new Scanner(System.in);
        String path = rootPath + "\\" +obj.nextLine();
        File folder = new File(path);
        boolean bool = folder.mkdir();
        if (bool){
            System.out.println("Directory created successfully.");
        }else{
            System.out.println("Sorry directory could not be created");
        }       
        
    }
    public static void createFolderNewDirectory(File rootPath) {
        
        System.out.println("List of folders in current path."); 
        folderList(rootPath);        
        
        System.out.println("Type in folder name to enter directory.");
        Scanner obj = new Scanner(System.in);
        String path = rootPath + "\\" +obj.nextLine();
        createFolder(path);
    }
    public static String printPretty() {
        String s = "\n  |";
        for(int i = 0; i <= iteration; i++)
            s += "---";
        return  s + " >> " ;
    }
    
    public static void folderList(File rootPath){
        
        
        for (String str : rootPath.list()) {
            File file = new File(rootPath + "\\" + str);
            if (file.isDirectory()) {
                System.out.println(printPretty() + file.getName());   
                iteration++;
                folderList(file);
            }
         }
        iteration--;
    }
    
    public static String changeDirectory(File rootPath){
        
        System.out.println("Current Directory :: "+rootPath);        
        System.out.println("Key in directory path to change into");
        Scanner obj = new Scanner(System.in);
        String path = rootPath + "\\\\" +obj.nextLine();
        System.out.println("Current Directory is now:: "+path);
        
        
        return path;
    }
    
    public static void deleteFolderWithContent(String rootPath){
        
        System.out.print(" Enter folder name to delete :: ");
        Scanner obj = new Scanner(System.in);
        String folderName = rootPath + "\\" + obj.nextLine();
        System.out.println(" Folder Name Entered is : " + folderName);
        File f = new File(folderName);
        deleteFolder(f);
      System.out.println("Folder deleted........");
    }
    
    public static void deleteFolder(File file){
      for (File subFile : file.listFiles()) {
         if(subFile.isDirectory()) {
            deleteFolder(subFile);
         } else {
            subFile.delete();
         }
      }
      file.delete();
   }
}
