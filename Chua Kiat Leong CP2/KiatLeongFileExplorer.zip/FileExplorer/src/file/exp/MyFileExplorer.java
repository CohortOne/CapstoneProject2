
package file.exp;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class MyFileExplorer {
    
    public static String rootDirectory;
    public static Scanner userInput = new Scanner(System.in);
    public static int iteration = 1;
    public static ArrayList<String> directoryListing = new ArrayList<String>();
    public static boolean changed = false;

    public static String getRootDirectory() {
        return rootDirectory;
    }

    public static void setRootDirectory(String rootDirectory) {
        
        MyFileExplorer.rootDirectory = rootDirectory;
    }
    
    public static void toContinue(){
        userInput.next();        
    }
    
    public static String betterAlignment(){
        String s = "\n  []";
        for(int i = 0; i <= iteration; i++)
            s += "---";
        return  s + ">> " ;
    }
    
    public static ArrayList recursivelyList(File folder) {
        
        for (String str : folder.list()) {
            File file = new File(folder + "\\" + str);
            if (file.isDirectory()) {
                directoryListing.add(betterAlignment() + file.getName());
                iteration++;
                recursivelyList(file);
            } else {
                directoryListing.add(betterAlignment() +  file.getName());
            }
        }
        iteration--;
        return directoryListing;
    }
    
    public static int dirOps(int opVal) {
        if (opVal == 0) {
            File rDir = new File(rootDirectory);
            recursivelyList(rDir);
            System.out.println(recursivelyList(rDir));
        }else if (opVal == 1){            
            MyFolderCC.createFolder(rootDirectory);    
        }
        else if (opVal == 2){            
            File rDir = new File(rootDirectory);
            MyFolderCC.createFolderNewDirectory(rDir);
            
        }else if (opVal == 3){            
            File rDir = new File(rootDirectory);
            MyFileExplorer.setRootDirectory(MyFolderCC.changeDirectory(rDir));           
            
        }
        else if (opVal == 4){            
            MyFileRW.fileReadandWrite();           
            
        }else if (opVal == 5){            
            MyFileRW.fileRead();
            
        }else if (opVal == 6){
            MyFileRW.copyFile(rootDirectory);
            
        }else if (opVal == 7){
            MyFileRW.renameFile(rootDirectory);
            
        }else if (opVal == 8){
            MyFileRW.deleteFile(rootDirectory);
            
        }else if (opVal == 9){
          //  File rDir = new File(rootDirectory);
            MyFolderCC.deleteFolderWithContent(rootDirectory);
            
        }
        
        return 0;
    }
    public static int DisplayOptions() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println("\n ********************************************************************************************* ");
        System.out.println("\n\tRoot Directory for File Operations ::: [" + rootDirectory+ "]");        
        System.out.println("\n ********************************************************************************************* ");

        System.out.println(" \tOptions available. :: ");
        System.out.println(" \n\t\t0 >> Directory Listing");
        System.out.println(" \n\t\t1 >> Create Directory in current Directory");
        System.out.println(" \n\t\t2 >> Create Directory in selected Directory");
        System.out.println(" \n\t\t3 >> Change Directory");
        System.out.println(" \n\t\t4 >> Create File in Current Directory  ");// Write to a File
        System.out.println(" \n\t\t5 >> Display File in Current Directory  ");// Echo Contents of a File
        System.out.println(" \n\t\t6 >> Copy File ");
        System.out.println(" \n\t\t7 >> Rename File");
        System.out.println(" \n\t\t8 >> Delete File ");
        System.out.println(" \n\t\t9 >> Delete Folder or Folders");
        System.out.println(" \n\t\t10 >> Reset to Root Folder");
        System.out.println(" \n\t\t* >> Exit ");

        System.out.println("\n ********************************************************************************************* ");
        // Create a Scanner object
        System.out.print(" Enter the option to carry out the operation  :   ");
        int optVal;
        try {
            optVal = userInput.nextInt();
        } catch (Exception e) {
            printHeader();
            System.out.println(" \n\n \t\t #### Invalid Option ####");
            optVal = -1;
        }
        return optVal;
    }
    
    public static void printHeader() throws Exception {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        System.out.println(" ============================================================================================");

    }

    public static void printFooter() {
        System.out.println(" ============================================================================================");
    }
    
    public static void main(String[] args) throws Exception {
        while (true) {
            int optionVal = 0;
            if (args.length > 0 && !changed ) {
                rootDirectory = args[0];
            }
             {
                File rootFolder = new File(rootDirectory);
                if (rootFolder.exists()) {
                    optionVal = DisplayOptions();
                } else {
                    new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
                    System.out.println(" \n\n\n\n\n");
                    System.out.println(" ===============================================================");
                    System.out.println("\t\t ROOT FOLDER NOT VALID ");
                    System.out.println(" ===============================================================");
                    Thread.sleep(5000);
                    System.out.println(" \n\n\n\n\n");
                    System.exit(0);
                }
            }
    
            printHeader();
            System.out.print("\t\t Option Selected : \t\t");
            switch (optionVal) {

                case 0:
                    System.out.println("Directory Listing");
                    dirOps(0);
                    break;
                case 1:
                    System.out.println("Create Directory");
                    dirOps(1);                    
                    break;
                case 2:
                    System.out.println("Create Directory in selected Directory");
                    dirOps(2);                    
                    break;
                case 3:
                    System.out.println("Change Directory");
                    dirOps(3);                    
                    changed = true;
                    break;
                case 4:
                    System.out.println("Create File");
                    dirOps(4);
                    break;
                case 5:
                    System.out.println("Display File");
                    dirOps(5);
                    break;
                case 6:
                    System.out.println("Copy File");
                    dirOps(6);
                    break;
                case 7:
                    System.out.println("Rename File");
                    dirOps(7);
                    break;
                case 8:
                    System.out.println("Delete File");
                    dirOps(8);
                    break;
                case 9:
                    System.out.println("Delete Folder or Folders");
                    dirOps(9);
                    break;
                case 10:
                    System.out.println("Reset to root folder");
                    changed = false;
                    break;
                case -1:
                    System.out.println("Exit");
                    printFooter();
                    Thread.sleep(4000);
                    System.exit(0);
                    break;
                default:
                    System.out.println(" Invalid Option, try again ");
                    break;
            }

            printFooter();
            System.out.print(" Press any key to continue.....");
            toContinue();
        }
    }
}
