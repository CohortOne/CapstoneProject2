package com.bank;

import core.banking.StudentAccount;


public class UniStudentAccount extends StudentAccount {

    public UniStudentAccount() {
        accNo = "10";
        accHolder = "20";
        postCode = "40";
    }

}
