/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core.banking;

/**
 *
 * @author chand
 */
public class ChildAccount extends Account {
    
    public ChildAccount(){
        super("","","","");
    }

    @Override
    public String withdraw(String amt) {
        // if parentalConsent is there then 
        super.withdraw(amt);
        return super.withdraw(amt); //To change body of generated methods, choose Tools | Templates.
    }

 
    
    public static void main(String [] args){
        ChildAccount ca = new ChildAccount();
        ca.withdraw();
    }
    
   
}
